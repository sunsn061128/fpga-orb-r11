-- ==============================================================
-- File generated on Tue Oct 13 15:03:35 +0800 2026
-- Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
-- SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
-- IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity fastv2_layer4_hls_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 7;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    -- axi4 lite slave signals
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    -- user signals
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC;
    ap_return             :in   STD_LOGIC_VECTOR(31 downto 0);
    image_r               :out  STD_LOGIC_VECTOR(31 downto 0);
    blurred               :out  STD_LOGIC_VECTOR(31 downto 0);
    resized               :out  STD_LOGIC_VECTOR(31 downto 0);
    selected              :out  STD_LOGIC_VECTOR(31 downto 0);
    result                :out  STD_LOGIC_VECTOR(31 downto 0);
    stats                 :out  STD_LOGIC_VECTOR(31 downto 0);
    level                 :out  STD_LOGIC_VECTOR(31 downto 0);
    budget                :out  STD_LOGIC_VECTOR(31 downto 0);
    high_threshold        :out  STD_LOGIC_VECTOR(31 downto 0);
    low_threshold         :out  STD_LOGIC_VECTOR(31 downto 0);
    dual_threshold        :out  STD_LOGIC_VECTOR(31 downto 0);
    selected_capacity     :out  STD_LOGIC_VECTOR(31 downto 0)
);
end entity fastv2_layer4_hls_control_s_axi;

-- ------------------------Address Info-------------------
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read)
--        bit 7  - auto_restart (Read/Write)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0  - Channel 0 (ap_done)
--        bit 1  - Channel 1 (ap_ready)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0  - Channel 0 (ap_done)
--        bit 1  - Channel 1 (ap_ready)
--        others - reserved
-- 0x10 : Data signal of ap_return
--        bit 31~0 - ap_return[31:0] (Read)
-- 0x18 : Data signal of image_r
--        bit 31~0 - image_r[31:0] (Read/Write)
-- 0x1c : reserved
-- 0x20 : Data signal of blurred
--        bit 31~0 - blurred[31:0] (Read/Write)
-- 0x24 : reserved
-- 0x28 : Data signal of resized
--        bit 31~0 - resized[31:0] (Read/Write)
-- 0x2c : reserved
-- 0x30 : Data signal of selected
--        bit 31~0 - selected[31:0] (Read/Write)
-- 0x34 : reserved
-- 0x38 : Data signal of result
--        bit 31~0 - result[31:0] (Read/Write)
-- 0x3c : reserved
-- 0x40 : Data signal of stats
--        bit 31~0 - stats[31:0] (Read/Write)
-- 0x44 : reserved
-- 0x48 : Data signal of level
--        bit 31~0 - level[31:0] (Read/Write)
-- 0x4c : reserved
-- 0x50 : Data signal of budget
--        bit 31~0 - budget[31:0] (Read/Write)
-- 0x54 : reserved
-- 0x58 : Data signal of high_threshold
--        bit 31~0 - high_threshold[31:0] (Read/Write)
-- 0x5c : reserved
-- 0x60 : Data signal of low_threshold
--        bit 31~0 - low_threshold[31:0] (Read/Write)
-- 0x64 : reserved
-- 0x68 : Data signal of dual_threshold
--        bit 31~0 - dual_threshold[31:0] (Read/Write)
-- 0x6c : reserved
-- 0x70 : Data signal of selected_capacity
--        bit 31~0 - selected_capacity[31:0] (Read/Write)
-- 0x74 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of fastv2_layer4_hls_control_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL                  : INTEGER := 16#00#;
    constant ADDR_GIE                      : INTEGER := 16#04#;
    constant ADDR_IER                      : INTEGER := 16#08#;
    constant ADDR_ISR                      : INTEGER := 16#0c#;
    constant ADDR_AP_RETURN_0              : INTEGER := 16#10#;
    constant ADDR_IMAGE_R_DATA_0           : INTEGER := 16#18#;
    constant ADDR_IMAGE_R_CTRL             : INTEGER := 16#1c#;
    constant ADDR_BLURRED_DATA_0           : INTEGER := 16#20#;
    constant ADDR_BLURRED_CTRL             : INTEGER := 16#24#;
    constant ADDR_RESIZED_DATA_0           : INTEGER := 16#28#;
    constant ADDR_RESIZED_CTRL             : INTEGER := 16#2c#;
    constant ADDR_SELECTED_DATA_0          : INTEGER := 16#30#;
    constant ADDR_SELECTED_CTRL            : INTEGER := 16#34#;
    constant ADDR_RESULT_DATA_0            : INTEGER := 16#38#;
    constant ADDR_RESULT_CTRL              : INTEGER := 16#3c#;
    constant ADDR_STATS_DATA_0             : INTEGER := 16#40#;
    constant ADDR_STATS_CTRL               : INTEGER := 16#44#;
    constant ADDR_LEVEL_DATA_0             : INTEGER := 16#48#;
    constant ADDR_LEVEL_CTRL               : INTEGER := 16#4c#;
    constant ADDR_BUDGET_DATA_0            : INTEGER := 16#50#;
    constant ADDR_BUDGET_CTRL              : INTEGER := 16#54#;
    constant ADDR_HIGH_THRESHOLD_DATA_0    : INTEGER := 16#58#;
    constant ADDR_HIGH_THRESHOLD_CTRL      : INTEGER := 16#5c#;
    constant ADDR_LOW_THRESHOLD_DATA_0     : INTEGER := 16#60#;
    constant ADDR_LOW_THRESHOLD_CTRL       : INTEGER := 16#64#;
    constant ADDR_DUAL_THRESHOLD_DATA_0    : INTEGER := 16#68#;
    constant ADDR_DUAL_THRESHOLD_CTRL      : INTEGER := 16#6c#;
    constant ADDR_SELECTED_CAPACITY_DATA_0 : INTEGER := 16#70#;
    constant ADDR_SELECTED_CAPACITY_CTRL   : INTEGER := 16#74#;
    constant ADDR_BITS         : INTEGER := 7;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(31 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(31 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_ap_idle         : STD_LOGIC;
    signal int_ap_ready        : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_ap_return       : UNSIGNED(31 downto 0);
    signal int_image_r         : UNSIGNED(31 downto 0) := (others => '0');
    signal int_blurred         : UNSIGNED(31 downto 0) := (others => '0');
    signal int_resized         : UNSIGNED(31 downto 0) := (others => '0');
    signal int_selected        : UNSIGNED(31 downto 0) := (others => '0');
    signal int_result          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_stats           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_level           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_budget          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_high_threshold  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_low_threshold   : UNSIGNED(31 downto 0) := (others => '0');
    signal int_dual_threshold  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_selected_capacity : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------

-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 0));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data <= (7 => int_auto_restart, 3 => int_ap_ready, 2 => int_ap_idle, 1 => int_ap_done, 0 => int_ap_start, others => '0');
                    when ADDR_GIE =>
                        rdata_data <= (0 => int_gie, others => '0');
                    when ADDR_IER =>
                        rdata_data <= (1 => int_ier(1), 0 => int_ier(0), others => '0');
                    when ADDR_ISR =>
                        rdata_data <= (1 => int_isr(1), 0 => int_isr(0), others => '0');
                    when ADDR_AP_RETURN_0 =>
                        rdata_data <= RESIZE(int_ap_return(31 downto 0), 32);
                    when ADDR_IMAGE_R_DATA_0 =>
                        rdata_data <= RESIZE(int_image_r(31 downto 0), 32);
                    when ADDR_BLURRED_DATA_0 =>
                        rdata_data <= RESIZE(int_blurred(31 downto 0), 32);
                    when ADDR_RESIZED_DATA_0 =>
                        rdata_data <= RESIZE(int_resized(31 downto 0), 32);
                    when ADDR_SELECTED_DATA_0 =>
                        rdata_data <= RESIZE(int_selected(31 downto 0), 32);
                    when ADDR_RESULT_DATA_0 =>
                        rdata_data <= RESIZE(int_result(31 downto 0), 32);
                    when ADDR_STATS_DATA_0 =>
                        rdata_data <= RESIZE(int_stats(31 downto 0), 32);
                    when ADDR_LEVEL_DATA_0 =>
                        rdata_data <= RESIZE(int_level(31 downto 0), 32);
                    when ADDR_BUDGET_DATA_0 =>
                        rdata_data <= RESIZE(int_budget(31 downto 0), 32);
                    when ADDR_HIGH_THRESHOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_high_threshold(31 downto 0), 32);
                    when ADDR_LOW_THRESHOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_low_threshold(31 downto 0), 32);
                    when ADDR_DUAL_THRESHOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_dual_threshold(31 downto 0), 32);
                    when ADDR_SELECTED_CAPACITY_DATA_0 =>
                        rdata_data <= RESIZE(int_selected_capacity(31 downto 0), 32);
                    when others =>
                        rdata_data <= (others => '0');
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_gie and (int_isr(0) or int_isr(1));
    ap_start             <= int_ap_start;
    image_r              <= STD_LOGIC_VECTOR(int_image_r);
    blurred              <= STD_LOGIC_VECTOR(int_blurred);
    resized              <= STD_LOGIC_VECTOR(int_resized);
    selected             <= STD_LOGIC_VECTOR(int_selected);
    result               <= STD_LOGIC_VECTOR(int_result);
    stats                <= STD_LOGIC_VECTOR(int_stats);
    level                <= STD_LOGIC_VECTOR(int_level);
    budget               <= STD_LOGIC_VECTOR(int_budget);
    high_threshold       <= STD_LOGIC_VECTOR(int_high_threshold);
    low_threshold        <= STD_LOGIC_VECTOR(int_low_threshold);
    dual_threshold       <= STD_LOGIC_VECTOR(int_dual_threshold);
    selected_capacity    <= STD_LOGIC_VECTOR(int_selected_capacity);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (ap_done = '1') then
                    int_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_ready <= ap_ready;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= "00";
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_return <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (ap_done = '1') then
                    int_ap_return <= UNSIGNED(ap_return);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGE_R_DATA_0) then
                    int_image_r(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_image_r(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BLURRED_DATA_0) then
                    int_blurred(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_blurred(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RESIZED_DATA_0) then
                    int_resized(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_resized(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SELECTED_DATA_0) then
                    int_selected(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_selected(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RESULT_DATA_0) then
                    int_result(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_result(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STATS_DATA_0) then
                    int_stats(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_stats(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LEVEL_DATA_0) then
                    int_level(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_level(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BUDGET_DATA_0) then
                    int_budget(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_budget(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_HIGH_THRESHOLD_DATA_0) then
                    int_high_threshold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_high_threshold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_LOW_THRESHOLD_DATA_0) then
                    int_low_threshold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_low_threshold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_DUAL_THRESHOLD_DATA_0) then
                    int_dual_threshold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_dual_threshold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_SELECTED_CAPACITY_DATA_0) then
                    int_selected_capacity(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_selected_capacity(31 downto 0));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
